BABY SHALOST — v9 MASCOT

Готовая статическая версия сайта для Netlify.
Главный файл: index.html
Изображения: assets/

Как загрузить:
1. Распакуйте ZIP.
2. В Netlify -> Production deploys выберите папку BABY_SHALOST_site_v9_mascot (или загрузите ZIP, если интерфейс принимает архив).
3. В корне публикации должен находиться index.html.

v9: новый монохромный маскот встроен в hero, портфолио, about и contact.
